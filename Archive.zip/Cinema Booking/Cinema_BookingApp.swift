import SwiftUI
import CoreImage.CIFilterBuiltins

@main
struct CinemaBookingApp: App {
    var body: some Scene {
        WindowGroup {
            LoginView()
        }
    }
}
